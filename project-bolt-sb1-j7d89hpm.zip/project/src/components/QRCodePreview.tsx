import React from 'react';
import { QRCodeConfig } from '../types/qr-types';
import { downloadQRCode } from '../utils/export-utils';
import { 
  Download, 
  Save, 
  Eye,
  Image,
  FileType,
  FileText
} from 'lucide-react';

interface QRCodePreviewProps {
  config: QRCodeConfig;
  qrDataUrl: string;
  onSaveToHistory: () => void;
}

const QRCodePreview: React.FC<QRCodePreviewProps> = ({ 
  config, 
  qrDataUrl, 
  onSaveToHistory 
}) => {
  const handleDownload = async (format: 'png' | 'svg' | 'pdf') => {
    if (!qrDataUrl) return;
    await downloadQRCode(qrDataUrl, config, format);
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6 space-y-6">
      <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
        <Eye className="w-6 h-6 text-green-600" />
        QR Code Preview
      </h2>

      {/* QR Code Display */}
      <div className="relative">
        <div 
          className="mx-auto rounded-2xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl"
          style={{ 
            backgroundColor: config.backgroundColor,
            width: 'fit-content'
          }}
        >
          {qrDataUrl ? (
            <img
              src={qrDataUrl}
              alt="Generated QR Code"
              className="block mx-auto rounded-lg"
              style={{ width: config.size, height: config.size }}
            />
          ) : (
            <div 
              className="flex items-center justify-center bg-gray-100 rounded-lg"
              style={{ width: config.size, height: config.size }}
            >
              <div className="text-center text-gray-500">
                <div className="w-16 h-16 mx-auto mb-2 bg-gray-200 rounded-lg flex items-center justify-center">
                  <Eye className="w-8 h-8" />
                </div>
                <p className="text-sm">Generating...</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* QR Code Info */}
      <div className="bg-gray-50 rounded-xl p-4 space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Type:</span>
          <span className="font-semibold text-gray-800 capitalize">{config.type}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Size:</span>
          <span className="font-semibold text-gray-800">{config.size}x{config.size}px</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Content Length:</span>
          <span className="font-semibold text-gray-800">{config.content.length} chars</span>
        </div>
      </div>

      {/* Save to History */}
      <button
        onClick={onSaveToHistory}
        disabled={!qrDataUrl}
        className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl hover:from-green-600 hover:to-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-semibold shadow-lg hover:shadow-xl"
      >
        <Save className="w-5 h-5" />
        Save to History
      </button>

      {/* Download Options */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
          <Download className="w-5 h-5 text-blue-600" />
          Download Options
        </h3>
        
        <div className="grid grid-cols-1 gap-3">
          <button
            onClick={() => handleDownload('png')}
            disabled={!qrDataUrl}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl hover:from-purple-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-medium shadow-md hover:shadow-lg"
          >
            <Image className="w-4 h-4" />
            Download PNG
          </button>

          <button
            onClick={() => handleDownload('svg')}
            disabled={!qrDataUrl}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-indigo-500 to-indigo-600 text-white rounded-xl hover:from-indigo-600 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-medium shadow-md hover:shadow-lg"
          >
            <FileType className="w-4 h-4" />
            Download SVG
          </button>

          <button
            onClick={() => handleDownload('pdf')}
            disabled={!qrDataUrl}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl hover:from-red-600 hover:to-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-medium shadow-md hover:shadow-lg"
          >
            <FileText className="w-4 h-4" />
            Download PDF
          </button>
        </div>
      </div>
    </div>
  );
};

export default QRCodePreview;