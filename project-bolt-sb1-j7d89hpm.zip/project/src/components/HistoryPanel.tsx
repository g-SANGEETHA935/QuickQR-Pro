import React from 'react';
import { HistoryEntry } from '../types/qr-types';
import { Trash2, Download, Calendar, Type, Palette } from 'lucide-react';

interface HistoryPanelProps {
  history: HistoryEntry[];
  onLoad: (entry: HistoryEntry) => void;
  onDelete: (id: string) => void;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onLoad, onDelete }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (history.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
          <Calendar className="w-8 h-8" />
        </div>
        <p>No QR codes saved yet</p>
        <p className="text-sm mt-1">Generated QR codes will appear here</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-h-96 overflow-y-auto">
      {history.map((entry) => (
        <div
          key={entry.id}
          className="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors border border-gray-200"
        >
          <div className="flex items-start gap-3">
            {/* QR Code Thumbnail */}
            <div className="flex-shrink-0">
              <img
                src={entry.dataUrl}
                alt="QR Code"
                className="w-16 h-16 rounded-lg border border-gray-200 shadow-sm"
              />
            </div>

            {/* Entry Details */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Type className="w-4 h-4 text-gray-400" />
                <span className="text-sm font-medium text-gray-800 capitalize">
                  {entry.config.type}
                </span>
              </div>
              
              <p className="text-sm text-gray-600 truncate mb-2">
                {entry.config.content}
              </p>

              <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                <div className="flex items-center gap-1">
                  <Palette className="w-3 h-3" />
                  <span>{entry.config.size}px</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(entry.createdAt)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <button
                  onClick={() => onLoad(entry)}
                  className="flex-1 px-3 py-1.5 bg-blue-600 text-white text-xs rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  <Download className="w-3 h-3 inline mr-1" />
                  Load
                </button>
                <button
                  onClick={() => onDelete(entry.id)}
                  className="px-3 py-1.5 bg-red-600 text-white text-xs rounded-lg hover:bg-red-700 transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default HistoryPanel;