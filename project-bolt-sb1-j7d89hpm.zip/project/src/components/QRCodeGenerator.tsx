import React from 'react';
import { QRCodeConfig, QRCodeType } from '../types/qr-types';
import { getQRTypeTemplates } from '../utils/qr-templates';
import { Palette, Maximize as Resize, Upload, Globe, Mail, MessageSquare, Phone, MapPin, Twitter, Youtube, User, CreditCard, Wifi, Music, Video, FileText, Share2 } from 'lucide-react';

interface QRCodeGeneratorProps {
  config: QRCodeConfig;
  onConfigChange: (config: QRCodeConfig) => void;
}

const typeIcons: Record<QRCodeType, React.ReactNode> = {
  url: <Globe className="w-4 h-4" />,
  email: <Mail className="w-4 h-4" />,
  text: <MessageSquare className="w-4 h-4" />,
  phone: <Phone className="w-4 h-4" />,
  sms: <MessageSquare className="w-4 h-4" />,
  location: <MapPin className="w-4 h-4" />,
  twitter: <Twitter className="w-4 h-4" />,
  youtube: <Youtube className="w-4 h-4" />,
  vcard: <User className="w-4 h-4" />,
  mecard: <CreditCard className="w-4 h-4" />,
  wifi: <Wifi className="w-4 h-4" />,
  mp3: <Music className="w-4 h-4" />,
  video: <Video className="w-4 h-4" />,
  pdf: <FileText className="w-4 h-4" />,
  social: <Share2 className="w-4 h-4" />
};

const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ config, onConfigChange }) => {
  const templates = getQRTypeTemplates();

  const handleTypeChange = (type: QRCodeType) => {
    const template = templates[type];
    onConfigChange({
      ...config,
      type,
      content: template.placeholder
    });
  };

  const handleContentChange = (content: string) => {
    onConfigChange({ ...config, content });
  };

  const handleSizeChange = (size: number) => {
    onConfigChange({ ...config, size });
  };

  const handleColorChange = (field: 'backgroundColor' | 'foregroundColor', color: string) => {
    onConfigChange({ ...config, [field]: color });
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        onConfigChange({ ...config, logo: e.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const currentTemplate = templates[config.type];

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6 space-y-6">
      <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
        <Palette className="w-6 h-6 text-blue-600" />
        Generator Settings
      </h2>

      {/* QR Code Type */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">
          QR Code Type:
        </label>
        <div className="relative">
          <select
            value={config.type}
            onChange={(e) => handleTypeChange(e.target.value as QRCodeType)}
            className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white shadow-sm"
          >
            {Object.entries(templates).map(([type, template]) => (
              <option key={type} value={type}>
                {template.label}
              </option>
            ))}
          </select>
          <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
            {typeIcons[config.type]}
          </div>
        </div>
      </div>

      {/* Content Input */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">
          Content:
        </label>
        <textarea
          value={config.content}
          onChange={(e) => handleContentChange(e.target.value)}
          placeholder={currentTemplate.placeholder}
          className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none shadow-sm"
          rows={4}
        />
        <p className="text-xs text-gray-500 mt-2">
          {currentTemplate.label} format will be applied automatically
        </p>
      </div>

      {/* Size Control */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Resize className="w-4 h-4" />
          Size: {config.size}px
        </label>
        <input
          type="range"
          min="128"
          max="512"
          step="16"
          value={config.size}
          onChange={(e) => handleSizeChange(parseInt(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>128px</span>
          <span>512px</span>
        </div>
      </div>

      {/* Color Controls */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Background Color:
          </label>
          <div className="flex gap-2">
            <input
              type="color"
              value={config.backgroundColor}
              onChange={(e) => handleColorChange('backgroundColor', e.target.value)}
              className="w-12 h-12 rounded-lg border border-gray-200 cursor-pointer"
            />
            <input
              type="text"
              value={config.backgroundColor}
              onChange={(e) => handleColorChange('backgroundColor', e.target.value)}
              className="flex-1 p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              placeholder="#ffffff"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Foreground Color:
          </label>
          <div className="flex gap-2">
            <input
              type="color"
              value={config.foregroundColor}
              onChange={(e) => handleColorChange('foregroundColor', e.target.value)}
              className="w-12 h-12 rounded-lg border border-gray-200 cursor-pointer"
            />
            <input
              type="text"
              value={config.foregroundColor}
              onChange={(e) => handleColorChange('foregroundColor', e.target.value)}
              className="flex-1 p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              placeholder="#000000"
            />
          </div>
        </div>
      </div>

      {/* Logo Upload */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Upload className="w-4 h-4" />
          Upload Logo:
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={handleLogoUpload}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-xl hover:border-blue-500 transition-colors">
            <div className="text-center">
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600">
                {config.logo ? 'Logo uploaded successfully' : 'Click to upload logo'}
              </p>
              <p className="text-xs text-gray-400 mt-1">PNG, JPG, SVG supported</p>
            </div>
          </div>
        </div>
        {config.logo && (
          <button
            onClick={() => onConfigChange({ ...config, logo: null })}
            className="mt-2 text-sm text-red-600 hover:text-red-800 transition-colors"
          >
            Remove Logo
          </button>
        )}
      </div>
    </div>
  );
};

export default QRCodeGenerator;