import QRCode from 'qrcode';
import { QRCodeConfig } from '../types/qr-types';
import { getQRTypeTemplates } from './qr-templates';

export const generateQRCode = async (config: QRCodeConfig): Promise<string> => {
  try {
    const templates = getQRTypeTemplates();
    const template = templates[config.type];
    const formattedContent = template.formatContent(config.content);

    const options: QRCode.QRCodeToDataURLOptions = {
      errorCorrectionLevel: 'M',
      type: 'image/png',
      quality: 0.92,
      margin: 1,
      color: {
        dark: config.foregroundColor,
        light: config.backgroundColor,
      },
      width: config.size,
    };

    let dataUrl = await QRCode.toDataURL(formattedContent, options);

    // If logo is provided, overlay it on the QR code
    if (config.logo) {
      dataUrl = await addLogoToQRCode(dataUrl, config.logo, config.size);
    }

    return dataUrl;
  } catch (error) {
    console.error('Error generating QR code:', error);
    return '';
  }
};

const addLogoToQRCode = async (qrDataUrl: string, logoDataUrl: string, size: number): Promise<string> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      resolve(qrDataUrl);
      return;
    }

    canvas.width = size;
    canvas.height = size;

    const qrImage = new Image();
    qrImage.onload = () => {
      // Draw QR code
      ctx.drawImage(qrImage, 0, 0, size, size);

      const logoImage = new Image();
      logoImage.onload = () => {
        // Calculate logo size (about 15% of QR code size)
        const logoSize = Math.min(size * 0.15, 60);
        const logoX = (size - logoSize) / 2;
        const logoY = (size - logoSize) / 2;

        // Create a white background for the logo
        ctx.fillStyle = 'white';
        ctx.fillRect(logoX - 5, logoY - 5, logoSize + 10, logoSize + 10);

        // Draw logo
        ctx.drawImage(logoImage, logoX, logoY, logoSize, logoSize);

        resolve(canvas.toDataURL('image/png'));
      };
      logoImage.src = logoDataUrl;
    };
    qrImage.src = qrDataUrl;
  });
};