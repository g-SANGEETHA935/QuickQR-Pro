import jsPDF from 'jspdf';
import { QRCodeConfig } from '../types/qr-types';

export const downloadQRCode = async (
  dataUrl: string, 
  config: QRCodeConfig, 
  format: 'png' | 'svg' | 'pdf'
): Promise<void> => {
  const fileName = `qr-code-${config.type}-${Date.now()}`;

  try {
    switch (format) {
      case 'png':
        await downloadPNG(dataUrl, fileName);
        break;
      case 'svg':
        await downloadSVG(dataUrl, fileName, config);
        break;
      case 'pdf':
        await downloadPDF(dataUrl, fileName, config);
        break;
    }
  } catch (error) {
    console.error(`Error downloading ${format.toUpperCase()}:`, error);
  }
};

const downloadPNG = async (dataUrl: string, fileName: string): Promise<void> => {
  const link = document.createElement('a');
  link.download = `${fileName}.png`;
  link.href = dataUrl;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const downloadSVG = async (dataUrl: string, fileName: string, config: QRCodeConfig): Promise<void> => {
  // Convert PNG data URL to SVG
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) return;

  const img = new Image();
  img.onload = () => {
    canvas.width = config.size;
    canvas.height = config.size;
    ctx.drawImage(img, 0, 0);

    // Create SVG content
    const svgContent = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${config.size}" height="${config.size}">
        <rect width="100%" height="100%" fill="${config.backgroundColor}"/>
        <image href="${dataUrl}" width="${config.size}" height="${config.size}"/>
      </svg>
    `;

    const blob = new Blob([svgContent], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.download = `${fileName}.svg`;
    link.href = url;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  };
  
  img.src = dataUrl;
};

const downloadPDF = async (dataUrl: string, fileName: string, config: QRCodeConfig): Promise<void> => {
  const pdf = new jsPDF();
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();
  
  // Calculate dimensions to center the QR code
  const qrSize = Math.min(pdfWidth * 0.6, pdfHeight * 0.6);
  const x = (pdfWidth - qrSize) / 2;
  const y = (pdfHeight - qrSize) / 2;

  // Add title
  pdf.setFontSize(20);
  pdf.setTextColor(60, 60, 60);
  pdf.text('QR Code', pdfWidth / 2, 30, { align: 'center' });

  // Add QR code image
  pdf.addImage(dataUrl, 'PNG', x, y, qrSize, qrSize);

  // Add details
  pdf.setFontSize(12);
  pdf.setTextColor(100, 100, 100);
  pdf.text(`Type: ${config.type.toUpperCase()}`, 20, pdfHeight - 40);
  pdf.text(`Size: ${config.size}x${config.size}px`, 20, pdfHeight - 25);
  pdf.text(`Generated: ${new Date().toLocaleString()}`, 20, pdfHeight - 10);

  pdf.save(`${fileName}.pdf`);
};