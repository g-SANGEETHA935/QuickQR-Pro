import { QRCodeType, QRTypeTemplate } from '../types/qr-types';

export const getQRTypeTemplates = (): Record<QRCodeType, QRTypeTemplate> => {
  return {
    url: {
      label: 'URL',
      placeholder: 'https://example.com',
      icon: 'globe',
      formatContent: (input: string) => {
        if (!input.startsWith('http://') && !input.startsWith('https://')) {
          return `https://${input}`;
        }
        return input;
      }
    },
    email: {
      label: 'Email',
      placeholder: 'user@example.com',
      icon: 'mail',
      formatContent: (input: string) => {
        const [email, subject, body] = input.split('|');
        let mailto = `mailto:${email}`;
        const params = [];
        if (subject) params.push(`subject=${encodeURIComponent(subject)}`);
        if (body) params.push(`body=${encodeURIComponent(body)}`);
        if (params.length > 0) mailto += `?${params.join('&')}`;
        return mailto;
      }
    },
    text: {
      label: 'Text',
      placeholder: 'Your text message here',
      icon: 'message-square',
      formatContent: (input: string) => input
    },
    phone: {
      label: 'Phone',
      placeholder: '+1234567890',
      icon: 'phone',
      formatContent: (input: string) => `tel:${input}`
    },
    sms: {
      label: 'SMS',
      placeholder: '+1234567890|Hello there!',
      icon: 'message-square',
      formatContent: (input: string) => {
        const [phone, message] = input.split('|');
        return `sms:${phone}${message ? `?body=${encodeURIComponent(message)}` : ''}`;
      }
    },
    location: {
      label: 'Location',
      placeholder: '40.7128,-74.0060|New York City',
      icon: 'map-pin',
      formatContent: (input: string) => {
        const [coords, label] = input.split('|');
        return `geo:${coords}${label ? `?q=${encodeURIComponent(label)}` : ''}`;
      }
    },
    twitter: {
      label: 'Twitter',
      placeholder: '@username',
      icon: 'twitter',
      formatContent: (input: string) => {
        const username = input.replace('@', '');
        return `https://twitter.com/${username}`;
      }
    },
    youtube: {
      label: 'YouTube',
      placeholder: 'https://youtube.com/watch?v=dQw4w9WgXcQ',
      icon: 'youtube',
      formatContent: (input: string) => {
        if (input.includes('youtube.com') || input.includes('youtu.be')) {
          return input;
        }
        return `https://youtube.com/watch?v=${input}`;
      }
    },
    vcard: {
      label: 'vCard',
      placeholder: 'John Doe|Company Inc|+1234567890|john@example.com',
      icon: 'user',
      formatContent: (input: string) => {
        const [name, org, phone, email] = input.split('|');
        return `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\n${org ? `ORG:${org}\n` : ''}${phone ? `TEL:${phone}\n` : ''}${email ? `EMAIL:${email}\n` : ''}END:VCARD`;
      }
    },
    mecard: {
      label: 'meCard',
      placeholder: 'John Doe|Company Inc|+1234567890|john@example.com',
      icon: 'credit-card',
      formatContent: (input: string) => {
        const [name, org, phone, email] = input.split('|');
        let mecard = `MECARD:N:${name}`;
        if (org) mecard += `;ORG:${org}`;
        if (phone) mecard += `;TEL:${phone}`;
        if (email) mecard += `;EMAIL:${email}`;
        mecard += ';;';
        return mecard;
      }
    },
    wifi: {
      label: 'WiFi',
      placeholder: 'MyNetwork|WPA|mypassword',
      icon: 'wifi',
      formatContent: (input: string) => {
        const [ssid, security, password] = input.split('|');
        return `WIFI:T:${security || 'WPA'};S:${ssid};P:${password || ''};;`;
      }
    },
    mp3: {
      label: 'MP3',
      placeholder: 'https://example.com/audio.mp3',
      icon: 'music',
      formatContent: (input: string) => input
    },
    video: {
      label: 'Video',
      placeholder: 'https://example.com/video.mp4',
      icon: 'video',
      formatContent: (input: string) => input
    },
    pdf: {
      label: 'PDF',
      placeholder: 'https://example.com/document.pdf',
      icon: 'file-text',
      formatContent: (input: string) => input
    },
    social: {
      label: 'Social Media',
      placeholder: 'https://instagram.com/username',
      icon: 'share-2',
      formatContent: (input: string) => input
    }
  };
};