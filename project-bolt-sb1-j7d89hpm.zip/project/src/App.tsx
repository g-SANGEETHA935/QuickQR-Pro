import React, { useState, useEffect } from 'react';
import QRCodeGenerator from './components/QRCodeGenerator';
import QRCodePreview from './components/QRCodePreview';
import HistoryPanel from './components/HistoryPanel';
import { QRCodeConfig, HistoryEntry } from './types/qr-types';
import { generateQRCode } from './utils/qr-generator';
import { History, QrCode, Download } from 'lucide-react';

function App() {
  const [config, setConfig] = useState<QRCodeConfig>({
    type: 'url',
    content: 'https://example.com',
    size: 256,
    backgroundColor: '#ffffff',
    foregroundColor: '#000000',
    logo: null
  });

  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    generateQRCode(config).then(setQrDataUrl);
  }, [config]);

  useEffect(() => {
    const savedHistory = localStorage.getItem('qr-history');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  const saveToHistory = () => {
    if (!qrDataUrl) return;
    
    const entry: HistoryEntry = {
      id: Date.now().toString(),
      config: { ...config },
      dataUrl: qrDataUrl,
      createdAt: new Date().toISOString()
    };

    const newHistory = [entry, ...history.slice(0, 19)]; // Keep only 20 recent entries
    setHistory(newHistory);
    localStorage.setItem('qr-history', JSON.stringify(newHistory));
  };

  const loadFromHistory = (entry: HistoryEntry) => {
    setConfig(entry.config);
    setShowHistory(false);
  };

  const deleteFromHistory = (id: string) => {
    const newHistory = history.filter(entry => entry.id !== id);
    setHistory(newHistory);
    localStorage.setItem('qr-history', JSON.stringify(newHistory));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl">
              <QrCode className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              QR Code Generator Pro
            </h1>
          </div>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Create professional QR codes with custom colors, logos, and multiple export formats. 
            Perfect for business cards, marketing materials, and digital campaigns.
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Generator Panel */}
          <div className="lg:col-span-1">
            <QRCodeGenerator config={config} onConfigChange={setConfig} />
          </div>

          {/* Preview Panel */}
          <div className="lg:col-span-1">
            <QRCodePreview 
              config={config} 
              qrDataUrl={qrDataUrl} 
              onSaveToHistory={saveToHistory}
            />
          </div>

          {/* History Panel */}
          <div className="lg:col-span-1">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <History className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-gray-800">History</h2>
                </div>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  {showHistory ? 'Hide' : 'Show'} History
                </button>
              </div>
              
              {showHistory && (
                <HistoryPanel
                  history={history}
                  onLoad={loadFromHistory}
                  onDelete={deleteFromHistory}
                />
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-gray-500">
          <p>© 2025 QR Code Generator Pro. Create, customize, and download professional QR codes.</p>
        </div>
      </div>
    </div>
  );
}

export default App;