export type QRCodeType = 
  | 'url' 
  | 'email' 
  | 'text' 
  | 'phone' 
  | 'sms' 
  | 'location' 
  | 'twitter' 
  | 'youtube' 
  | 'vcard' 
  | 'mecard' 
  | 'wifi' 
  | 'mp3' 
  | 'video' 
  | 'pdf' 
  | 'social';

export interface QRCodeConfig {
  type: QRCodeType;
  content: string;
  size: number;
  backgroundColor: string;
  foregroundColor: string;
  logo: string | null;
}

export interface HistoryEntry {
  id: string;
  config: QRCodeConfig;
  dataUrl: string;
  createdAt: string;
}

export interface QRTypeTemplate {
  label: string;
  placeholder: string;
  icon: string;
  formatContent: (input: string) => string;
}